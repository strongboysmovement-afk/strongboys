// МЭДЭЭ НЭМЭХ ЗААВАР: доорх массивт шинэ объект хуулж нэмнэ.
// Огноог YYYY.MM.DD хэлбэрээр бичнэ. Баталгаажаагүй мэдээлэл бүү нийтэл.
const news = [
  {
    category: "Хөтөлбөрийн мэдээлэл",
    date: "2026.11.25",
    title: "Хүчирхэг хөвгүүд хөгжлийн хөтөлбөр",
    summary: "Өсвөр насны хөвгүүдийн хөгжил, жендэрийн хэвшмэл ойлголтыг өөрчлөх, эрүүл харилцааг дэмжих хөтөлбөрийн танилцуулга.",
    url: "#about"
  }
];
const list = document.getElementById("news-list");
list.innerHTML = news.map(item => `
  <article class="news-card">
    <div class="thumb">ХҮЧИРХЭГ ХӨВГҮҮД</div>
    <div class="body">
      <div class="tag">${item.category}</div>
      <h3>${item.title}</h3>
      <p>${item.summary}</p>
      <div class="date">${item.date}</div>
      <p style="margin-top:12px"><a href="${item.url}" style="color:#2378a8;font-weight:700">Дэлгэрэнгүй →</a></p>
    </div>
  </article>`).join("");
document.getElementById("year").textContent = new Date().getFullYear();
